Readme File
2020/06/28-16:31:16
This package contains HyperSQL v. 2.5.1

HyperSQL Database is a relational database management system and a set of tools
written in Java.
HyperSQL is also known as HSQLDB.

The file "index.html" explains the contents of this distribution and has
links to documentation and support resources.
